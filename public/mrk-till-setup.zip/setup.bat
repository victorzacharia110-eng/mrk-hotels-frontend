@echo off
title MRK Hotels - QZ Tray Till Setup
REM One double-click, one permission prompt. Relaunch elevated if we are not
REM already admin so the QZ Tray install and the certificate trust both happen
REM without interrupting the operator again.
net session >nul 2>&1
if %errorlevel%==0 goto :run
echo Requesting administrator rights (one prompt)...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
exit /b

:run
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1"
echo.
pause
