@echo off
title MRK Hotels - QZ Tray Till Setup
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1"
echo.
pause
