MRK HOTELS — TILL SETUP (Windows)
=================================

Do these three things, in order.

1. INSTALL QZ TRAY (once)
   Double-click  setup.bat
   - Installs QZ Tray if it is not already there (one "Yes" on the Windows
     admin prompt).
   - Trusts the MRK root certificate so printing is SILENT (no "Allow" dialog).
   - Starts QZ Tray. A small QZ icon appears in the system tray.

   If Windows blocks the file: right-click setup.bat -> Properties -> Unblock.

2. INSTALL THE PRINTER (once)
   Plug in the printer (USB), then Settings -> Bluetooth & devices -> Printers
   & scanners -> Add device. Use the vendor's driver if you have one, otherwise
   "Generic / Text Only" works for ESC/POS thermal printers.

3. PICK THE PRINTER IN THE APP (once, on this till)
   Open the app -> Cashier -> Print settings -> choose the printer -> Test
   print. A receipt should come out with no dialog.

TROUBLESHOOTING
- "Allow / Block / Remember" dialog appears: QZ Tray did not pick up the
  certificate. Close QZ from the tray, re-run setup.bat, then try again.
- Printer prints gibberish: wrong driver. Switch the printer's driver to
  "Generic / Text Only" (or the vendor's ESC/POS driver).
- "Printer not found" in the app: the printer is not installed in Windows, or
  the name selected in Print settings does not match the Windows printer name.
