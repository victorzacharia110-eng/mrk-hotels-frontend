MRK HOTELS - TILL SETUP (Windows)
=================================

Do these three things, in order.

1. INSTALL QZ TRAY AND TRUST THE CERTIFICATE (once)
   Just double-click  setup.bat  ->  click "Yes" once on the Windows prompt.
   (No need to right-click "Run as administrator" - the script elevates itself.)
   It does everything in one go:
   - Installs QZ Tray if it is not already there.
   - Copies override.crt into the QZ Tray folder so printing is SILENT
     (no "Allow" dialog).
   - Clears any earlier "Block" that would stop printing.
   - Restarts QZ Tray. A small QZ icon appears in the system tray.
   - Prints an "OK" verdict when silent printing is correctly configured.

   If Windows blocks the file: right-click setup.bat -> Properties -> Unblock.

2. INSTALL THE PRINTER (once)
   Plug in the printer (USB), then Settings -> Bluetooth & devices -> Printers
   & scanners -> Add device. Use the vendor's driver if you have one, otherwise
   "Generic / Text Only" works for ESC/POS thermal printers.

3. PICK THE PRINTER IN THE APP (once, on this till)
   Open the app -> Cashier -> Print settings -> choose the printer -> Test
   print. A receipt should come out with no dialog.

TROUBLESHOOTING
- "MRK Hotels wants to connect ... Untrusted website": QZ Tray is running but
  does not trust the MRK root certificate. Re-run setup.bat (as admin). It now
  also configures QZ's -DtrustedRootCert launch option, which works regardless
  of where QZ Tray reads its files, and prints which check passed.
  If it still shows UNTRUSTED, close the browser completely and reopen the app.
- "QZ Industries, LLC wants to print" (note: NOT "MRK Hotels"): the browser is
  not sending the MRK certificate. Hard-refresh the page (Ctrl+Shift+R) or use a
  Private window - the till is running a stale cached copy of the app.
- "Allow / Block / Remember" dialog still appears: override.crt is not being
  read. Re-run setup.bat as administrator; it reports which of the three trust
  mechanisms took effect.
- The connection is refused with NO dialog at all: a previous "Block" decision
  is remembered. Run setup.bat again (it clears it), or open the QZ Tray tray
  icon -> Advanced -> Site Manager -> Blocked and remove the MRK entry.
- Printer prints gibberish: wrong driver. Switch the printer's driver to
  "Generic / Text Only" (or the vendor's ESC/POS driver).
- "Printer not found" in the app: the printer is not installed in Windows, or
  the name selected in Print settings does not match the Windows printer name.
