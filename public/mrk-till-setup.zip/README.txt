MRK HOTELS - TILL SETUP (Windows)
=================================

Do these three things, in order.

1. INSTALL QZ TRAY AND TRUST THE CERTIFICATE (once)
   Right-click  setup.bat  ->  Run as administrator  ->  Yes.
   - Installs QZ Tray if it is not already there.
   - Copies override.crt into the QZ Tray folder so printing is SILENT
     (no "Allow" dialog). This needs administrator rights, so the script asks
     for one "Yes" on the Windows prompt - that is expected.
   - Restarts QZ Tray. A small QZ icon appears in the system tray.

   If Windows blocks the file: right-click setup.bat -> Properties -> Unblock.

2. INSTALL THE PRINTER (once)
   Plug in the printer (USB), then Settings -> Bluetooth & devices -> Printers
   & scanners -> Add device. Use the vendor's driver if you have one, otherwise
   "Generic / Text Only" works for ESC/POS thermal printers.

3. PICK THE PRINTER IN THE APP (once, on this till)
   Open the app -> Cashier -> Print settings -> choose the printer -> Test
   print. A receipt should come out with no dialog.

TROUBLESHOOTING
- "Allow / Block / Remember" dialog still appears: override.crt is not in the
  QZ Tray folder. Either re-run setup.bat as administrator, or open the QZ Tray
  tray icon -> Advanced -> Diagnostic -> Browse App Folder and copy override.crt
  from this folder into that folder, then restart QZ Tray.
- Printer prints gibberish: wrong driver. Switch the printer's driver to
  "Generic / Text Only" (or the vendor's ESC/POS driver).
- "Printer not found" in the app: the printer is not installed in Windows, or
  the name selected in Print settings does not match the Windows printer name.
