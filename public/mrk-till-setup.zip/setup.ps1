# MRK Hotels - QZ Tray till setup (Windows)
#
# One double-click installs and configures everything the till needs:
#   1. Installs QZ Tray (only if it is missing).
#   2. Trusts the MRK Hotels root certificate, so printing is silent.
#   3. Starts QZ Tray.
#
# setup.bat relaunches itself elevated first, so this script normally runs with
# administrator rights and never interrupts the operator mid-run. It still falls
# back to a single one-off elevation below if it is somehow started unelevated.
#
# Trust mechanism (QZ Tray >= 2.1): a file named exactly "override.crt" placed
# in QZ Tray's install folder is loaded automatically as a trusted root. That is
# the documented way to suppress the "Allow / Block" dialog, but it silently
# fails if QZ reads a different folder than the one we write (bundled-Java
# layout, per-user install, a service). So the script ALSO configures the
# layout-independent -DtrustedRootCert launch option via QZ_OPTS and an
# authcert.override properties entry, and reports which of the three took.
#
# The trusted root is written to the install folder (needs admin) and to
# %APPDATA%\qz\override.crt (user scope). Nothing else is touched.
#
# The private signing key never comes near this machine: the browser fetches the
# public certificate from the API and asks it to sign each print message.

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$QZ_VERSION = '2.3.0'
$QZ_URL = "https://github.com/qzind/tray/releases/download/v$QZ_VERSION/qz-tray-$QZ_VERSION-x86_64.exe"
$CertSource = Join-Path $PSScriptRoot 'override.crt'

function Step($msg) { Write-Host "`n==> $msg" -ForegroundColor Cyan }
function Warn($msg) { Write-Host "  !  $msg" -ForegroundColor Yellow }

# --- Locate QZ Tray ----------------------------------------------------------
function Find-QzHome {
    $candidates = @()
    if ($env:ProgramFiles)        { $candidates += (Join-Path $env:ProgramFiles 'QZ Tray') }
    if (${env:ProgramFiles(x86)}) { $candidates += (Join-Path ${env:ProgramFiles(x86)} 'QZ Tray') }
    if ($env:LOCALAPPDATA)        { $candidates += (Join-Path $env:LOCALAPPDATA 'Programs\QZ Tray') }
    if ($env:LOCALAPPDATA)        { $candidates += (Join-Path $env:LOCALAPPDATA 'QZ Tray') }
    foreach ($dir in $candidates) {
        if ($dir -and (Test-Path (Join-Path $dir 'qz-tray.exe'))) { return $dir }
    }
    # Last resort: ask a running QZ Tray where it lives.
    $proc = Get-Process -Name 'qz-tray' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($proc -and $proc.Path) { return (Split-Path $proc.Path -Parent) }
    return $null
}

# Copy override.crt into $dest, elevating only this one copy if needed, and
# confirm the exact file landed (hash check) before reporting success.
function Install-Override([string]$dest) {
    function SameAsSource([string]$path) {
        try {
            return ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -eq
                    (Get-FileHash -LiteralPath $CertSource -Algorithm SHA256).Hash)
        } catch { return $true }  # unreadable but present - good enough
    }

    try { Copy-Item -LiteralPath $CertSource -Destination $dest -Force } catch { }
    if ((Test-Path $dest) -and (SameAsSource $dest)) { return $true }

    Step "Requesting administrator rights to trust the certificate (one prompt)..."
    try {
        $cmd = "Copy-Item -LiteralPath '$CertSource' -Destination '$dest' -Force"
        Start-Process -FilePath 'powershell' -Verb RunAs -Wait `
            -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', $cmd)
    } catch { }
    return ((Test-Path $dest) -and (SameAsSource $dest))
}

# Verify, as far as is possible without a browser, that QZ Tray will trust the
# signing certificate at its next startup. Three independent mechanisms count:
#   1. override.crt present in the install dir AND matching the root we ship
#      (the documented mechanism since QZ 2.1); or
#   2. qz-tray.properties carries an authcert.override entry; or
#   3. a QZ_OPTS env var carries -DtrustedRootCert (layout-independent).
# Returns @{ Ok = $bool; Message = <string>; Color = <ConsoleColor> }.
function Test-QzTrust([string]$qzHome, [string]$installTarget) {
    $roadWarn = 'the "Allow" dialog will appear on this till.'

    if ((Test-Path $installTarget) -and (Test-Path $CertSource)) {
        $a = (Get-FileHash -LiteralPath $installTarget -Algorithm SHA256).Hash
        $b = (Get-FileHash -LiteralPath $CertSource -Algorithm SHA256).Hash
        if ($a -eq $b) {
            return @{ Ok = $true; Color = 'Green'; Message = "OK - $installTarget matches the MRK root certificate." }
        }
        Warn "MISMATCH - $installTarget is not the MRK root certificate; relying on the other mechanisms below."
    }

    $props = @((Join-Path $qzHome 'qz-tray.properties'), (Join-Path (Join-Path $env:APPDATA 'qz') 'qz-tray.properties'))
    foreach ($p in $props) {
        try {
            if ((Test-Path $p) -and (Select-String -Path $p -Pattern '^\s*authcert\.override' -Quiet)) {
                return @{ Ok = $true; Color = 'Green'; Message = "OK - authcert.override recorded in $p." }
            }
        } catch { }
    }

    foreach ($scope in @('Process', 'Machine', 'User')) {
        try {
            $opts = [Environment]::GetEnvironmentVariable('QZ_OPTS', $scope)
            if ($opts -and $opts -match 'trustedRootCert') {
                return @{ Ok = $true; Color = 'Green'; Message = "OK - $scope QZ_OPTS carries -DtrustedRootCert." }
            }
        } catch { }
    }

    return @{ Ok = $false; Color = 'Red'; Message = "NOT CONFIGURED - no trusted-root mechanism is in place; $roadWarn" }
}

$qzHome = Find-QzHome
if (-not $qzHome) {
    Step "QZ Tray not found - downloading and installing (one admin prompt)..."
    $installer = Join-Path $env:TEMP "qz-tray-$QZ_VERSION-x86_64.exe"
    Invoke-WebRequest -Uri $QZ_URL -OutFile $installer
    Start-Process $installer -ArgumentList '/VERYSILENT', '/SUPPRESSMSGBOXES', '/NORESTART' -Wait
    $qzHome = Find-QzHome
    if (-not $qzHome) {
        throw "QZ Tray did not install. Install it manually, then run this again."
    }
}
Write-Host "QZ Tray found at: $qzHome"

# --- Trust the MRK root certificate -----------------------------------------
Step "Trusting the MRK Hotels root certificate (silent printing)..."
if (-not (Test-Path $CertSource)) {
    throw "override.crt is missing next to this script. Re-copy the whole till-setup folder."
}

$target = Join-Path $qzHome 'override.crt'
$installed = Install-Override $target

if ($installed) {
    Write-Host "override.crt installed: $target" -ForegroundColor Green
}

# Belt and braces: a successful copy does NOT guarantee QZ Tray trusts it. The
# file can land in a folder the running launcher never reads (bundled-Java
# layout, per-user install, a service, etc.), which shows up in the browser as
# "MRK Hotels wants to connect ... Untrusted website". QZ's documented,
# layout-independent mechanism is the -DtrustedRootCert launch option, honoured
# via the QZ_OPTS environment variable. Always configure it as well, pointing at
# a copy we control, so trust does not depend on file placement alone.
$userDir = Join-Path $env:APPDATA 'qz'
New-Item -ItemType Directory -Force -Path $userDir | Out-Null
$overrideFile = Join-Path $userDir 'override.crt'
Copy-Item -LiteralPath $CertSource -Destination $overrideFile -Force
Write-Host "User-profile copy: $overrideFile" -ForegroundColor Green

foreach ($props in @((Join-Path $qzHome 'qz-tray.properties'), (Join-Path $userDir 'qz-tray.properties'))) {
    try {
        if (-not (Test-Path $props) -or -not (Select-String -Path $props -Pattern '^\s*authcert\.override' -Quiet)) {
            Add-Content -Path $props -Value "authcert.override=$overrideFile"
            Write-Host "Recorded authcert.override in $props"
        }
    } catch { Warn "Could not update $props (needs admin) - skipping." }
}

# QZ_OPTS is read at process launch; set it at Machine scope (we are elevated)
# so it applies no matter which user starts QZ Tray, then fall back to User.
$optValue = "-DtrustedRootCert=$overrideFile"
try {
    [Environment]::SetEnvironmentVariable('QZ_OPTS', $optValue, 'Machine')
    Write-Host "Set machine QZ_OPTS -> $optValue"
} catch {
    [Environment]::SetEnvironmentVariable('QZ_OPTS', $optValue, 'User')
    Write-Host "Set user QZ_OPTS -> $optValue"
}

# --- Clear any remembered "Block" decision -----------------------------------
# If an operator ever clicked "Block", QZ Tray remembers it in blocked.dat and
# refuses the connection with no visible prompt. A trust install must clear that
# so the site is not silently locked out. (allowed.dat is left alone - it only
# ever grants, never denies.)
Step "Clearing any remembered Block decision..."
$qzUserDir = Join-Path $env:APPDATA 'qz'
$blocked = Join-Path $qzUserDir 'blocked.dat'
if (Test-Path $blocked) {
    $size = (Get-Item $blocked).Length
    if ($size -gt 0) {
        Remove-Item -LiteralPath $blocked -Force -ErrorAction SilentlyContinue
        if (Test-Path $blocked) {
            Warn "Could not clear $blocked - clear it manually (QZ Tray > Advanced > Site Manager > Blocked)."
        } else {
            Write-Host "Cleared a previous Block decision ($blocked)." -ForegroundColor Green
        }
    }
}

# --- Restart QZ Tray ---------------------------------------------------------
Step "Restarting QZ Tray..."
Get-Process -Name 'qz-tray' -ErrorAction SilentlyContinue | Stop-Process -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2
# Machine-scope QZ_OPTS will not be seen by this already-running shell, so also
# set it in the current process before launching QZ Tray - the child inherits it.
$env:QZ_OPTS = $optValue
$qzExe = Join-Path $qzHome 'qz-tray.exe'
if (Test-Path $qzExe) { Start-Process $qzExe } else { Start-Process 'qz-tray' }
Start-Sleep -Seconds 6

# --- Verify the trusted root actually loaded ---------------------------------
# Silent printing depends on QZ reading override.crt at startup. If it did not
# take, we must say so loudly rather than let the operator hit the "Allow"
# dialog and assume the fix failed.
Step "Verifying silent printing is configured..."
$verdict = Test-QzTrust $qzHome $target
Write-Host $verdict.Message -ForegroundColor $verdict.Color
if (-not $verdict.Ok) {
    Warn "Silent printing is NOT confirmed. Do not ignore this - printing will prompt until it is fixed."
}

Step "QZ Tray is ready. Two steps left:"
Write-Host @"
  1. Install the printer in Windows (Settings -> Bluetooth & devices -> Printers
     & scanners -> Add device). Use the vendor's driver, or "Generic / Text
     Only" for ESC/POS thermal printers.
  2. Open the app -> Cashier -> Print settings -> pick the printer -> Test
     print. No "Allow" dialog should appear.
"@
