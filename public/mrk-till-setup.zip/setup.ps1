# MRK Hotels — QZ Tray till setup (Windows)
#
# One double-click installs and configures everything the till needs:
#   1. Installs QZ Tray (only if it is missing).
#   2. Trusts the MRK Hotels root certificate, so printing is silent.
#   3. Starts QZ Tray.
#
# The private signing key never comes near this machine: the browser fetches the
# public certificate from the API and asks it to sign each print message.

$ErrorActionPreference = 'Stop'
$QZ_VERSION = '2.3.0'
$QZ_URL = "https://github.com/qzind/tray/releases/download/v$QZ_VERSION/qz-tray-$QZ_VERSION-x86_64.exe"
$CertSource = Join-Path $PSScriptRoot 'override.crt'

function Step($msg) { Write-Host "`n==> $msg" -ForegroundColor Cyan }

# --- 1. Locate QZ Tray -------------------------------------------------------
function Find-QzHome {
    foreach ($p in @($env:ProgramFiles, ${env:ProgramFiles(x86)})) {
        if ($p) {
            $dir = Join-Path $p 'QZ Tray'
            if (Test-Path (Join-Path $dir 'qz-tray.exe')) { return $dir }
        }
    }
    return $null
}

$qzHome = Find-QzHome
if (-not $qzHome) {
    Step "QZ Tray not found - downloading and installing (one admin prompt)..."
    $installer = Join-Path $env:TEMP "qz-tray-$QZ_VERSION-x86_64.exe"
    Invoke-WebRequest -Uri $QZ_URL -OutFile $installer
    Start-Process $installer -ArgumentList '/VERYSILENT', '/SUPPRESSMSGBOXES', '/NORESTART' -Wait
    $qzHome = Find-QzHome
    if (-not $qzHome) {
        throw "QZ Tray did not install. Install it manually, then run this again."
    }
}
Write-Host "QZ Tray found at: $qzHome"

# --- 2. Trust the MRK root certificate ---------------------------------------
Step "Trusting the MRK Hotels root certificate (silent printing)..."
if (-not (Test-Path $CertSource)) {
    throw "override.crt is missing next to this script. Re-copy the whole till-setup folder."
}

$installedToProgramFiles = $false
try {
    Copy-Item $CertSource (Join-Path $qzHome 'override.crt') -Force
    $installedToProgramFiles = $true
} catch {
    Write-Host "Install folder is not writable - requesting elevation..."
    $elevated = "powershell -NoProfile -ExecutionPolicy Bypass -Command `"Copy-Item '$CertSource' '$(Join-Path $qzHome 'override.crt')' -Force`""
    try {
        Start-Process powershell -Verb RunAs -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', "Copy-Item '$CertSource' '$(Join-Path $qzHome 'override.crt')' -Force" -Wait
        $installedToProgramFiles = Test-Path (Join-Path $qzHome 'override.crt')
    } catch {
        Write-Warning "Elevation was declined."
    }
}

# Belt-and-braces: also drop the certificate in the user profile and point
# QZ's `authcert.override` at it. This needs no admin rights at all, so the
# till is covered even when elevation is blocked.
$userDir = Join-Path $env:APPDATA 'qz'
New-Item -ItemType Directory -Force -Path $userDir | Out-Null
Copy-Item $CertSource (Join-Path $userDir 'override.crt') -Force
$props = Join-Path $userDir 'qz-tray.properties'
if (-not (Test-Path $props) -or -not (Select-String -Path $props -Pattern '^\s*authcert\.override' -Quiet)) {
    Add-Content -Path $props -Value "authcert.override=$userDir"
    Write-Host "Recorded authcert.override in $props"
}

if (-not $installedToProgramFiles) {
    Write-Warning "Could not write to $qzHome - relying on the user-profile copy instead."
}

# --- 3. Start QZ Tray --------------------------------------------------------
Step "Starting QZ Tray..."
Get-Process -Name 'qz-tray' -ErrorAction SilentlyContinue | Stop-Process -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2
$qzExe = Join-Path $qzHome 'qz-tray.exe'
if (Test-Path $qzExe) { Start-Process $qzExe } else { Start-Process 'qz-tray' }
Start-Sleep -Seconds 5

Step "QZ Tray is ready. Two steps left:"
Write-Host @"
  1. Install the printer in Windows (Settings -> Bluetooth & devices -> Printers
     & scanners -> Add device). Use the vendor's driver, or "Generic / Text
     Only" for ESC/POS thermal printers.
  2. Open the app -> Cashier -> Print settings -> pick the printer -> Test
     print. No "Allow" dialog should appear.
"@
