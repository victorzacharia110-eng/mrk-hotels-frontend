# MRK Hotels - QZ Tray till setup (Windows)
#
# One double-click installs and configures everything the till needs:
#   1. Installs QZ Tray (only if it is missing).
#   2. Trusts the MRK Hotels root certificate, so printing is silent.
#   3. Starts QZ Tray.
#
# Trust mechanism (QZ Tray >= 2.1): a file named exactly "override.crt" placed
# in QZ Tray's install folder is loaded automatically as a trusted root. That is
# the reliable, persistent way to suppress the "Allow / Block" dialog. Writing
# into the install folder needs admin, so this script asks for it for that one
# copy. A no-admin fallback (user-profile copy + authcert.override / QZ_OPTS) is
# used only if the install folder cannot be written.
#
# Nothing is deleted. override.crt is the only file written, and the fallback
# only APPENDS a properties line / sets a user env var when it is not there yet.
#
# The private signing key never comes near this machine: the browser fetches the
# public certificate from the API and asks it to sign each print message.

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$QZ_VERSION = '2.3.0'
$QZ_URL = "https://github.com/qzind/tray/releases/download/v$QZ_VERSION/qz-tray-$QZ_VERSION-x86_64.exe"
$CertSource = Join-Path $PSScriptRoot 'override.crt'

function Step($msg) { Write-Host "`n==> $msg" -ForegroundColor Cyan }
function Warn($msg) { Write-Host "  !  $msg" -ForegroundColor Yellow }

# --- Locate QZ Tray ----------------------------------------------------------
function Find-QzHome {
    $candidates = @()
    if ($env:ProgramFiles)        { $candidates += (Join-Path $env:ProgramFiles 'QZ Tray') }
    if (${env:ProgramFiles(x86)}) { $candidates += (Join-Path ${env:ProgramFiles(x86)} 'QZ Tray') }
    if ($env:LOCALAPPDATA)        { $candidates += (Join-Path $env:LOCALAPPDATA 'Programs\QZ Tray') }
    if ($env:LOCALAPPDATA)        { $candidates += (Join-Path $env:LOCALAPPDATA 'QZ Tray') }
    foreach ($dir in $candidates) {
        if ($dir -and (Test-Path (Join-Path $dir 'qz-tray.exe'))) { return $dir }
    }
    # Last resort: ask a running QZ Tray where it lives.
    $proc = Get-Process -Name 'qz-tray' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($proc -and $proc.Path) { return (Split-Path $proc.Path -Parent) }
    return $null
}

# Copy override.crt into $dest, elevating only this one copy if needed, and
# confirm the exact file landed (hash check) before reporting success.
function Install-Override([string]$dest) {
    function SameAsSource([string]$path) {
        try {
            return ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -eq
                    (Get-FileHash -LiteralPath $CertSource -Algorithm SHA256).Hash)
        } catch { return $true }  # unreadable but present - good enough
    }

    try { Copy-Item -LiteralPath $CertSource -Destination $dest -Force } catch { }
    if ((Test-Path $dest) -and (SameAsSource $dest)) { return $true }

    Step "Requesting administrator rights to trust the certificate (one prompt)..."
    try {
        $cmd = "Copy-Item -LiteralPath '$CertSource' -Destination '$dest' -Force"
        Start-Process -FilePath 'powershell' -Verb RunAs -Wait `
            -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', $cmd)
    } catch { }
    return ((Test-Path $dest) -and (SameAsSource $dest))
}

$qzHome = Find-QzHome
if (-not $qzHome) {
    Step "QZ Tray not found - downloading and installing (one admin prompt)..."
    $installer = Join-Path $env:TEMP "qz-tray-$QZ_VERSION-x86_64.exe"
    Invoke-WebRequest -Uri $QZ_URL -OutFile $installer
    Start-Process $installer -ArgumentList '/VERYSILENT', '/SUPPRESSMSGBOXES', '/NORESTART' -Wait
    $qzHome = Find-QzHome
    if (-not $qzHome) {
        throw "QZ Tray did not install. Install it manually, then run this again."
    }
}
Write-Host "QZ Tray found at: $qzHome"

# --- Trust the MRK root certificate -----------------------------------------
Step "Trusting the MRK Hotels root certificate (silent printing)..."
if (-not (Test-Path $CertSource)) {
    throw "override.crt is missing next to this script. Re-copy the whole till-setup folder."
}

$target = Join-Path $qzHome 'override.crt'
$installed = Install-Override $target

if ($installed) {
    Write-Host "override.crt installed: $target" -ForegroundColor Green
} else {
    # Last resort that needs no admin: keep a copy in the user profile and point
    # QZ at the FILE (authcert.override is a file path, not a folder).
    Warn "The QZ Tray folder could not be written. Using the user-profile copy instead."
    $userDir = Join-Path $env:APPDATA 'qz'
    New-Item -ItemType Directory -Force -Path $userDir | Out-Null
    $overrideFile = Join-Path $userDir 'override.crt'
    Copy-Item -LiteralPath $CertSource -Destination $overrideFile -Force
    foreach ($props in @((Join-Path $qzHome 'qz-tray.properties'), (Join-Path $userDir 'qz-tray.properties'))) {
        try {
            if (-not (Test-Path $props) -or -not (Select-String -Path $props -Pattern '^\s*authcert\.override' -Quiet)) {
                Add-Content -Path $props -Value "authcert.override=$overrideFile"
                Write-Host "Recorded authcert.override in $props"
            }
        } catch { Warn "Could not update $props (needs admin) - skipping." }
    }
    # QZ also honours QZ_OPTS; set it only when the user has not set it already.
    $existingOpts = [Environment]::GetEnvironmentVariable('QZ_OPTS', 'User')
    if (-not $existingOpts) {
        [Environment]::SetEnvironmentVariable('QZ_OPTS', "-DtrustedRootCert=$overrideFile", 'User')
        Write-Host "Set user environment QZ_OPTS -> $overrideFile"
    } else {
        Warn "QZ_OPTS is already set ('$existingOpts'); left untouched."
    }
}

# --- Restart QZ Tray ---------------------------------------------------------
Step "Restarting QZ Tray..."
Get-Process -Name 'qz-tray' -ErrorAction SilentlyContinue | Stop-Process -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2
$qzExe = Join-Path $qzHome 'qz-tray.exe'
if (Test-Path $qzExe) { Start-Process $qzExe } else { Start-Process 'qz-tray' }
Start-Sleep -Seconds 5

Step "QZ Tray is ready. Two steps left:"
Write-Host @"
  1. Install the printer in Windows (Settings -> Bluetooth & devices -> Printers
     & scanners -> Add device). Use the vendor's driver, or "Generic / Text
     Only" for ESC/POS thermal printers.
  2. Open the app -> Cashier -> Print settings -> pick the printer -> Test
     print. No "Allow" dialog should appear.
"@
